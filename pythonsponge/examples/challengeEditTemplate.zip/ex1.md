# Example

Pages can be marked as *example* pages. These require no code change, and are marked as completed immediately when the student runs the code. 

This is done in the challenge settings which use the JSON format and can be found in the EDIT CHALLENGE tab of the lower left panel in this workspace. To make a challenge an example, the JSON requires the attribute isExample to be set to true.

*Note: the page is marked as completed on the book report once the program finishes execution. E.g. in this case after providing some input. This is to encourage engagement with the example program*

Once you have made a change to a page then use the SAVE icon below to update it. You can also use the PREVIEW link to open a new updated tab on the current book which can then be closed once you have finished testing.

Now try editing this guide page to give student instructions for your first challenge, update the starter code then use the SAVE icon again and progress to the next page of your book.

You can write any valid markdown in the guide: see the reference [here](https://www.markdownguide.org/basic-syntax/).