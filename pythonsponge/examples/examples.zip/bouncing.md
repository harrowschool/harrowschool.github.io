Enjoy our simple python game which is controlling a canvas in the html webpage.

Use the left and right arrows to control the paddle once the game has started.

### TASKS
* Add more blocks and/or change the size and colour of the blocks
* Add a score counter to count your score (number of blocks destroyed) and print it out when you die
* Stop the paddle going off both edges
* Give the player three lives before the game is over
* What else might you want to add in?