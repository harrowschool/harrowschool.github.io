# Write some code here to prompt the user for their name,
# then print out "Hello <name> (Bob says hi)"
# (replacing name with the user input)

name = input("Enter name")
print(f"Hello {name} (Bob says hi)")
