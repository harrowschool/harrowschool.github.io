word = input("enter a five letter word: ")
letters = list(word)
result = letters[2] + letters[_] + letters[_] + letters[_] + letters[_]
print(f"an anagram is {result}")