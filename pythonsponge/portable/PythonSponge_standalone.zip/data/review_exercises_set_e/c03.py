distance = 
speed = 
time = 
print(f"the time required is {time} seconds")