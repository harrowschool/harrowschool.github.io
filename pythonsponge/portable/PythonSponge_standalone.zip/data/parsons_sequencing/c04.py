base = float(input("enter base:"))
height = base + 2
area = base * height / 2
print(f"area of triangle: {area}")