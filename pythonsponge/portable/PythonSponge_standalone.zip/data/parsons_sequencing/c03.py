counter = 3
print(counter)
counter = counter - 1
print(counter)
counter = counter - 1
print(counter)
print("bast off!")