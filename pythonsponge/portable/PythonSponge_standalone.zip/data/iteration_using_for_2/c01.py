word = input("enter a word: ")
print("here are the characters from the word...")
for ch in word:
    print(ch)