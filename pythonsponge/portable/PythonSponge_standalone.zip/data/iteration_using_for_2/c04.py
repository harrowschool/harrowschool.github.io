word = input("enter a string to find the vowel index positions e.g. rabbit: ")
for i, ch in enumerate(____):
    if __ in "ae___":
        print(_)