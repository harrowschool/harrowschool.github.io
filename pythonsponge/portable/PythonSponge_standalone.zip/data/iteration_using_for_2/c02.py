word = input("enter a mix of characters a-z, A-Z, digits and symbols: ")
result = ""
for ch in ____:
    if ch.isalpha():
        result += __
print(______)