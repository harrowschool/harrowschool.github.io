for num in _____________
    print(___)