for num in range(10, 30, 5):
    print(num)
