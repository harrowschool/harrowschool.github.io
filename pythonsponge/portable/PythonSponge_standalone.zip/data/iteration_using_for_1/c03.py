for count in range(3):
    print("hello")
