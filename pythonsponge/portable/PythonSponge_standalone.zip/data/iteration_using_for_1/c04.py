total = 0
for count in range(5):
    num = int(input("next number: "))
    total += ___
print(_____)