def do_chorus():
    print("ooh la la")
    print("ooh lay lay")
    print("having a happy day")
	
print("whistling on my summer walk")
print("all around me cheerful talk")

do_chorus()

print("with my friends and a take-away meal")
print("we just got a scorching deal")

do_chorus()