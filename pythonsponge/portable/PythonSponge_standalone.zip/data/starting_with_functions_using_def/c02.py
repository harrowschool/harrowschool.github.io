def terminator():
    print("+------------+")

def report_divider():
    print("+~~~~~~~~~~~~+")

terminator()

print(f"|{'Jane':^12}|")

report_divider()

print(f"|{'Craig':^12}|")

# add a call to the report_divider procedure here

print(f"|{'Margaret':^12}|")

# add a call to the report_divider procedure here

print(f"|{'Jonathan':^12}|")

terminator()