name = input("enter name: ")
print("hello", name)
