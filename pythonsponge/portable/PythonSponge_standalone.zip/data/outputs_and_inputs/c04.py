firstname = input("firstname? ")
surname = input(surname?)
print("your full name is", surname, firstname)