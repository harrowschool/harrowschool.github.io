print("What is your favourite colour?")
colour = input()

print("I also like", colour)