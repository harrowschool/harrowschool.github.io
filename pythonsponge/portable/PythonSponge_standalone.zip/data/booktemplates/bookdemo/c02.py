# DEBUG THIS CODE!
name = input
print("Hello", name