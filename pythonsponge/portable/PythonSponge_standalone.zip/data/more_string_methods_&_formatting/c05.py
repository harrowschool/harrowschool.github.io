a = int(input("enter whole number a: "))
b = ___(input("enter whole number b: "))

result = a / _

print("+----------+")
print(f"|{_____:______}|")
print("+----------+")