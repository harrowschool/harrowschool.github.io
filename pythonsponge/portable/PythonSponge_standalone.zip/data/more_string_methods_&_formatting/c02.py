word = input("enter a word: ")

x_index = word.find(___)

print("the next letter after your first x is")

if x_index == __ or x_index == len(____) - 1:
    print("impossible")
else:
    next_index = _______ + _
    print(word[__________])