firstname = input("firstname: ")
surname = input("surname: ")

print("have a badge...\n")

print("+------------+------------+")
print(f"|{firstname:^12}|{surname:^12}|")
print("+------------+------------+")
