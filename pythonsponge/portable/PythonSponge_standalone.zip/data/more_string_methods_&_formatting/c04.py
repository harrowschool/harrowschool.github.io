from math import pi

print("the number pi to 4 decimal places is:")

print("+------------+")
print(f"|{pi:>12.4f}|")
print("+------------+")