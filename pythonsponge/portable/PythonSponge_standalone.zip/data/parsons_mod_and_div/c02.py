num = int(input("enter start number 0-19: "))
num *= 2
num = num % 20
print(num)