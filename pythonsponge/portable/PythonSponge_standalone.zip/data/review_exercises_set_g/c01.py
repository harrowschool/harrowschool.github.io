letters = input("enter some space-separated letters e.g. f a u m t x d: ").split(___)
duplicate = letters[_]
duplicate.s___()
print("original", letters)
print("duplicate", duplicate)