def get_initials(lst):
    result = list(___)
    for index in range(len(result)):
        item = result[_____]
        result[index] = item[0]
    return ______

animals = input("enter some comma separated animals e.g. dog,cat,frog: ").split(",")
initials = get_initials(animals)
print("tell someone the initials:", ________)
print("...and see if they can guess your animals:", animals)