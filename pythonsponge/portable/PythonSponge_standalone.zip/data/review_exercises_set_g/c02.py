def say_greeting(name):
  print(f"Hi {name}")
  
names = []
for _ in range(3):
    names.append(input("next name: "))
	
for name in names:
    ____________(____)