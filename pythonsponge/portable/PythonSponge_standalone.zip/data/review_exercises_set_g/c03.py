def find_digit_sum(num):
    total = 0
    for digit in str(___):
        total += int(_____)
    return _____

choice_num = input("enter a number with multiple digits: ")
digit_sum = find_digit_sum(choice_num)
print(f"the digit sum is {digit_sum}")