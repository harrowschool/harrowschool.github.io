letter = input("enter a single upper-case character: ")
code = ___(letter)
lowercaseCode = code + __
lowercaseLetter = ___(lowercaseCode)
print("using my ASCII machine I have crunched it into the letter:", lowercaseLetter)