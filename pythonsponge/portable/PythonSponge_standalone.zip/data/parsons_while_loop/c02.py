start = int(input("enter a positive whole number to start: "))
while start < 1000:
    start *= 2
    print("...which when doubled gives", start)
print("which is quite large enough thank you")