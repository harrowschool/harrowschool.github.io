password = input("enter the password: ")
while password != "frog":
    print("that's not right, try again")
    password = input("enter the password: ")
print("well done, you are allowed in!")