def say_hello(greeting_type, name):
    if greeting_type.lower() == "formal":
        result = f"Dear {name}"
    elif greeting_type.lower() == "informal":
        result = f"Hiya {____}"
    else:
        result = "unknown greeting type"
    
    return result

firstname = input("enter your firstname: ")
choice = input("enter your greeting type - formal or informal: ")

message = say_hello(____, _________)
print(_______)