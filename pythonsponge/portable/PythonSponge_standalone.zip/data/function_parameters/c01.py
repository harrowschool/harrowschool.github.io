def do_jump(num_times, jump_where):
    for count in range(num_times):
        print(f"jumping {jump_where}")
	
do_jump(3, "in the puddle")
print("like we're in a muddle")

do_jump(2, "in the pond")
print("like we don't respond")