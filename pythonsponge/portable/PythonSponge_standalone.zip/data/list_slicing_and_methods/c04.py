sentence = ["the", "large", "cat", "sat", "on", "the"]

word = input("enter a word to add to the end of my sentence: ")

sentence.append(____)

print("_".join(________))