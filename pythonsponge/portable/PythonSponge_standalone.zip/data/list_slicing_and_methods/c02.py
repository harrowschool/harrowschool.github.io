weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

work_days = weekdays[_:_]

print(f"buckle up for...{work_days}")