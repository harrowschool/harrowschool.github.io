evens = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20]

# slice out items at index 1, 2, 3 & 4 into a new list
starter = evens[1:5]

for num in starter:
    print(num)
	
print("who do we appreciate?")