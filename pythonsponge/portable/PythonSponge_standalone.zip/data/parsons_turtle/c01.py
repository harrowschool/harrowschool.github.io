for i in range(0,$$toggle::2::3::4$$):
	myTurtle.forward(100)
	myTurtle.left(120)