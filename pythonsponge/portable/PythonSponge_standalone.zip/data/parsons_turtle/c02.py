for i in range(0, $$toggle::2::3::4::5::6$$):
  myTurtle.forward($$toggle::50::100::150$$)
  myTurtle.left($$toggle::90::180::270::360$$)
myTurtle.pencolor("red")
for i in range(0, $$toggle::2::3::4::5::6$$):
  myTurtle.forward($$toggle::50::100::150$$)
  myTurtle.left($$toggle::90::180::270$::360$$)