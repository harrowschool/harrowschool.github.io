pets = ['dog', 'cat', 'rabbit']
pets.append("crocodile")
pets.insert(1, "hamster")
print(pets)