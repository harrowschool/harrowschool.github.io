colours = []
colA = input("enter your favourite colour: ")
colours.ap____(colA)
colB = input("enter your worst colour: ")
colours.ap____(____)
colC = input("finally enter a neutral colour i.e. which you don't mind: ")
colours.in___(_, colC)
print("your ordered colours list is", colours)