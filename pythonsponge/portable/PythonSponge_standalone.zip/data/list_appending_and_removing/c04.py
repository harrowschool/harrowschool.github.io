stationary = ['pencil', 'protractor', 'pen', 'ruler', 'scissors', 'stapler']
choice = input("enter an item to remove or enter a digit 1-6 to remove by position: ")
if choice.isdigit():
    pos = int(choice) - 1
    stationary.p__(___)
else:
    stationary.r_____(______)
print("your final list is", stationary)