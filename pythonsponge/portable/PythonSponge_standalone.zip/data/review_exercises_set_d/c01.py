num1 = int(input("enter a larger positive whole number to start e.g. 15: "))
num2 = int(input("enter a smaller positive whole number to count down in e.g. 3: "))
for count in range(num1, _ , _____):
    print(_____)