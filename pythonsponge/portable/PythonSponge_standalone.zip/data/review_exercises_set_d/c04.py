result = ""
word = input("enter a word with a mix of upper and lower case letters e.g. Rat: ")

for letter in ____:
    if letter.islower():
        result += letter._____()
    else:
        ______ __ _____________
		
print(result)