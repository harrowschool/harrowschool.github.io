word = input("enter a word: ")
while True:
    numChoice = input("enter a number 1, 2 or 3: ")
    if numChoice in "123":
        _____
num = int(_________)
result = word[:___]
print(result)