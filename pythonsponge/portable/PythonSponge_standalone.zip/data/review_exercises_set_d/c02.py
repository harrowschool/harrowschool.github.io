word = input("enter a word: ")
result = word[____]
print(______)