num1 = 
num2 = 
result = 
print(result)