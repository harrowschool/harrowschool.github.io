celsius = int(input("temp. in Celsius? ")
fahrenheit = celsius * (1.8 + 32)
print(fahrenheit)