LBS_IN_STONE = 14
weight_in_lbs = int(input("enter weight in lbs: "))
stone = ___________ // ___________
lbs = ___________ % ___________
print(f"that weight is {stone} stone and {lbs} lbs")