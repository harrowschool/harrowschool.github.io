print("The whole part of 14 divided by 3 is", 14 // 3)
print("...and the remainder from 14 divided by 3 is", 14 % 3)

print("The whole part of 26 divided by 7 is", 26 // 7)
print("...and the remainder from 26 divided by 7 is", 26 % 7)

a = 12
b = 4
print(f"The whole part of {a} divided by {b} is", a // b)
print(f"...and the remainder from {a} divided by {b} is", a % b)