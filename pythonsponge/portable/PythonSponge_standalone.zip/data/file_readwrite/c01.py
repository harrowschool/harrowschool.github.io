file = open("data.txt", "w")

print("enter the name of three friends...")

for idx in range(3):
	if idx > 0:
		file.write("\n")
		file.write(input('enter your next name: '))

file.close()
print("all done...now proceed to the next exercise where we will load your data back...")