def makeTriangle():
    print("   /\\   ")
    print("  /  \\  ")
    print(" /____\\ ")
makeTriangle()
makeTriangle()