def doThreeTwoOne():
    for num in range(3, 0, -1):
        print(num)
for count in range(4):
    doThreeTwoOne()