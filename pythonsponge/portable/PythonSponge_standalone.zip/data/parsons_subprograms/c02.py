def doHeadShoulders():
    print("head, shoulders, knees and toes")
    print("knees and toes")    
doHeadShoulders()
doHeadShoulders()
print("eyes and ears and mouth and nose")
doHeadShoulders()