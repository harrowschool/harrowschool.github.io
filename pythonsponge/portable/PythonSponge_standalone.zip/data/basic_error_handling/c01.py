try:
    num = int(input("enter a whole number: "))
    print("well done you!")
except:
    print("that was not a whole number!")

print("you cannot crash me whatever you type!")