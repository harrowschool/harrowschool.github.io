myFruits = ["apple", "banana", "pear", "orange", "grape", "strawberry"]

t__:
    word = input("enter a fruit: ").lower()
    position = myFruits.index(word) + 1
    print("that comes at position", ________, "in my list of favourites")
e_____:
    print("it looks like I don't like that fruit at all!")

print("thanks for playing!")