rainy_kit = ['hat', 'coat', 'umbrella', 'cagool']

print("it is raining, please can you all get your...")

for word in rainy_kit:
    print(f"{word}s", end="...")