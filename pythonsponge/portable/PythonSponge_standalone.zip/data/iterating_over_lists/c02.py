colours = ["red", "orange", "purple", "indigo"]
print("can you guess my four colours?")
print("they begin with the letters...")
for col in _______:
    print(col[_], end=" ")