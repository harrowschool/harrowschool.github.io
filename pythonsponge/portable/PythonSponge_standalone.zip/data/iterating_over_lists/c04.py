letters = input("enter comma-separated letters: ").split(",")
count = 0

for index, letter in e________(letters):
    next_index = index + _
    if l_____ == "x" and (next_index == len(letters) or letters[next_index] != "_"):
        count += _

print(count)