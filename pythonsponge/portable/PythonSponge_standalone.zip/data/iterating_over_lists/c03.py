personal_allowances = [11850, 12500, 12500, 12570]

for i in range(len(personal_allowances)):
    print(f"in tax year starting April {2018 + i}...")
    print(f"the income tax personal allowance was £{personal_allowances[i]}")

print("BETTER METHOD")

for year, allowance in enumerate(personal_allowances):
    print(f"in tax year starting April {2018 + year}...")
    print(f"the income tax personal allowance was £{allowance}")