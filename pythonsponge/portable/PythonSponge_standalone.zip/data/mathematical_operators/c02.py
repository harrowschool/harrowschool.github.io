num1 = 7
num2 = 4
result = num1 + num2
print(num1, "*", num2, "=", num1)