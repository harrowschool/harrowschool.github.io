print(5 + 3)
result = 15 / 3
print(result)