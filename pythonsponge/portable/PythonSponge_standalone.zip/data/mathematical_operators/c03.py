print(2 ** 3)
print(11 // 4)
print(11 % 4)
