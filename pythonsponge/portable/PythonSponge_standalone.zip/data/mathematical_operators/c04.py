num1 = 5
num2 = 3
num3 = 26
# complete the next line to calculate num1 to the power num2
result1 = 
# complete the next line to calculate the integer division of num3 by num2
result2 = 
# complete the next line to calculate the remainder when num3 is divided by num1
result3 = 
print("Answers:", result1, result2, result3)