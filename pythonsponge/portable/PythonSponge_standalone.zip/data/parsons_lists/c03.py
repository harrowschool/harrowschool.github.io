colours = ["blue", "green", "indigo", "red", "yellow"]
index = 0
colour = input(f"enter a new colour not in {colours}: ")
while index < len(colours):
  if colour < colours[index]:
    break
  index += 1
colours.insert(index, colour)
print("alphabetical colours:", colours)