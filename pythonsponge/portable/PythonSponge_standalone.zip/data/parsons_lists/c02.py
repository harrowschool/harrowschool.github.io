flowers = []
for count in range(3):
  flower = input("enter favourite flowers in order: ")
  flowers.append(flower)
print("So you like:", flowers)