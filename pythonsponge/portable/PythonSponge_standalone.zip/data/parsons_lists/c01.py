friends = ["Julie", "Naveena", "Annabel", "Issy"]
for i in range(0, len(friends)):
    print(f"{i+1})", friends[i])