choice = input("enter 1 for beep, 2 for bop or 3 for boop: ")
if choice == "1":
    print("beep")
else:
    print("choice not recognised")
	
print("goodbye")