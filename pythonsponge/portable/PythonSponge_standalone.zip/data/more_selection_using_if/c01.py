name = input("your firstname? ")
if name == "Jack" or name == "jack":
    print("we spoke last week!")
elif name == "Natalie" or name == "natalie":
    print("I've been meaning to text!")
elif name == "Ayesha" or name == "Ayesha":
    print("it has been a long time")
else:
    print("I'm not sure we've met before")
	
print("nice chatting anyway, got to go...")