num = int(input("enter a whole number: "))
if num < 10:
    print("very small")
elif num < 20:
    print("middling I suppose")
elif num < 30:
    print("getting there")
else:
    print("now you're talking!")
	
print("now go and have a rest...")
