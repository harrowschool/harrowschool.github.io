num = int(input("enter a positive whole number: "))
if num > 0:
    print("positive")
elif num > 10:
    print("above ten")
elif num > 20:
    print("above twenty")
else:
    print("positive only please")