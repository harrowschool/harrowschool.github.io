num = 1
while True:
    if num ** 2 >= __:
        ____
    print(num * num)
    num = num + 1