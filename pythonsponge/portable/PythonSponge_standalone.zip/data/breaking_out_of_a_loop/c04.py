lifePoints = 0
while True:
    print("current life points:", lifePoints)
    newPoints = int(input("enter more life points or 0 to finish"))
    if newPoints == _:
        ____
    lifePoints += _________
    
print("final life points score:", __________)