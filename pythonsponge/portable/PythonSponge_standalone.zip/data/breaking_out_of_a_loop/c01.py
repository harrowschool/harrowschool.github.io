while True:
    print("hello")
    choice = input("are you bored yet (y/n)?")
    if choice.lower() == "y":
        break