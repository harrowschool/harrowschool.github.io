def sayHelloTo(name):
    print(f"Hello {name}")
sayHelloTo("Jack")