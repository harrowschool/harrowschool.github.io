def combineWithAnd(word1, word2):
    result = word1 + " and " + word2
    print(result)
combineWithAnd("fish", "chips")