def makeRow(char, num):
    print(char * num)
for row in range(1, 6):
    makeRow("*", row)