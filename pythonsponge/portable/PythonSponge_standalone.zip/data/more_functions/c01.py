def doMultiply(a, b, c=1, d=1):
    return a * b * c * d

print("two squared is...")	
print(doMultiply(2, 2))

print("two to the power three is equal to...")	
print(doMultiply(2, 2, 2))

print("two to the power four is equal to...")	
print(doMultiply(2, 2, 2, 2))