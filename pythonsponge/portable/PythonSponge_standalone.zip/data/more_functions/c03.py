def make_smoothie(fruit1, fruit2, fruit3):
    print("blending...")
    print(fruit1)
    print(fruit2)
    print(fruit3)
    print("bing....enjoy!")

myFruits = ["grape", "strawberry", "banana"]

make_smoothie(*myFruits)
