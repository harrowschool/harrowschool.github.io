def friends_badge(name1, name2, name3):
    print("=====================")
    print(f"|{name1:^19}|")
    print(f"|{name2:^19}|")
    print(f"|{name3:^19}|")
    print("=====================")
    print("|  FRIENDS FOREVER  |")
    print("=====================")
	
names = []

for index in range(3):
    names.a_____(input("next friend name? "))
	
friends_badge(*_____)