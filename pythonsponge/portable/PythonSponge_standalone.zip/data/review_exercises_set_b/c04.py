phrase = input("enter a phrase that contains every vowel at least once:").upper()
if "A" in phrase and "E"