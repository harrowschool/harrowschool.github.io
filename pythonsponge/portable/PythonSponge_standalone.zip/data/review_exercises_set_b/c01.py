if input("yes or no?") == "yes"
print("I like positive!")
else
print("hands-up not hands-out please!")