day = input("enter a day of the week e.g. Monday: ")
if day.lower() == "monday":
    print("tomorrow is Tuesday")
elif day.lower() == "tuesday":
    print("tomorrow is Wednesday")
else:
    print("I don't know that day")