num1 = int(input("whole number 1?"))
num2 = 
if num1 == num2 + 1 or 
    print("consecutive")
else: