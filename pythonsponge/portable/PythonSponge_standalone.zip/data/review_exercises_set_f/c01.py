fruits = input("enter fruits comma separated: ").split(___)

for index, fruit in e________(fruits):
    print(f"{_________}){_____.upper()}")