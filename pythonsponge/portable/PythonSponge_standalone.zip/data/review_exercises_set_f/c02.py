names = ["Amy", "Mark", "Ayeesha", "William", "Sayeeta", "Trevor"]

choice1 = int(input("enter an index 0-5: "))
choice2 = int(input("enter an index 0-5: "))

index1 = min(choice1, choice2)
index2 = max(choice1, choice2)

chosen = names[______:________]

print("_".j___(______))