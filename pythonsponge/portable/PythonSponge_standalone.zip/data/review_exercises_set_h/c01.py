start = int(input("enter start ASCII code number e.g. 65: "))
end = int(input("enter end ASCII code number e.g. 95: "))

for code in range(_____, end + 1):
  print(code, end=" ")
  print(f"{code:>08b}", end=" ")
  print(___(code))