days = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]

while True:
  day = input("enter a valid three letter day e.g. WED: ").upper()
  try:
    idx = days.index(___)
    br___
  ex____:
    print("please enter a valid day...try again...")
	
idx = (idx + 1) % len(____)
print(f"the next day is {days[idx]}")