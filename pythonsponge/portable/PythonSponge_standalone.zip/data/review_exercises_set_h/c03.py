def printCharByChar(word, isRightToLeft = False):
	if _____________:
		word = word[::-1]  # to reverse the string if a right to left language by slicing the whole string backwards
	for ch in word:
		print(__)

word1 = "cat"
word2 = "חתול"  # cat in Hebrew which is right to left

printCharByChar(word1)
printCharByChar(word2, ____)