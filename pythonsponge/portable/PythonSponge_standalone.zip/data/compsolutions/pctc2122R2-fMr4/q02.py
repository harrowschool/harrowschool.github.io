amount = float(input())
fifties_remainder = amount % 50
print(round(50 - fifties_remainder, 1))
