digits = input()
freq = [0] * 10

def get_median(fr_list):
    med_index = (sum(fr_list) + 1) // 2
    count = 0
    index = 0
    while count < med_index:
        count += fr_list[index]
        index += 1
    return index - 1

result = ""

for i in range(0, len(digits)):
    freq[int(digits[i])] += 1
    result += str(get_median(freq))

print(result)