choices = input("enter some names separated by commas, as many as you want: ")
names = choices.split(",")
names[__] = "_____"
print("I've made a small change...")
print(names)