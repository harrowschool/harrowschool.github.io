choices = input("enter your 3 favourite animals separated by a comma e.g. cat,fish,dog: ")
animalsList = choices.split(",")
firstChoice = animalsList[_]
print("your first choice was", ___________)