friendNames = ["Esme", "Patrick", "Elodie", "Aryan"]
myFriend = friendNames[0]
print(myFriend)