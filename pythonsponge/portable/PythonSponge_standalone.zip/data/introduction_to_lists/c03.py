oddNums = [1, 3, 4, 7]
print("the first four odd numbers are", oddNums)
print("whoops let me fix one...")
oddNums[2] = 5
print("the first four odd numbers are", oddNums)

