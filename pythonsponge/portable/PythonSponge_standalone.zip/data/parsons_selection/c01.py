choice = input("king or queen? ")
if choice == "queen":
    print("welcome your majesty the queen")
else:
    print("welcome your majesty the king")