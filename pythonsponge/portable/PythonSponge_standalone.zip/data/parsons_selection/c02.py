temperature = float(input("enter freezer temperature in deg Celcius: "))
if temperature <= 0:
    print("you can get ice cubes")
else:
    print("you can't get ice cubes")"