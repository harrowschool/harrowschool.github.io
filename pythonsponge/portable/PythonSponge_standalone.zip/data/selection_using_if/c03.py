num = int(input("enter a whole number: "))
if num < 1000:
    print("quite small I think")
else:
    print("you've gone large!")
    print("I'm impressed.")
	
print("thanks for playing")