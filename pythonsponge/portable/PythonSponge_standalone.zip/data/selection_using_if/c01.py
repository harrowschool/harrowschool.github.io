num = int(input("enter a whole number: "))
if num >= 100:
    print("you've gone large!")
    print("I'm impressed.")
	
print("thanks for playing")