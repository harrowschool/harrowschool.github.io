SECRET_PASSWORD = "apple"
user_pw = input("guess the password: ")
if user_pw == SECRET_PASSWORD
print("correct")

print("thanks for playing")