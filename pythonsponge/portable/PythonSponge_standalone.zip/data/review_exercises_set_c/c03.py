num = 1
while True:
    print("hell" + "o" * num)
    choice = input("enter stop to exit or anything else to continue: ")
    if choice == ________
        _____
    num = num + 1