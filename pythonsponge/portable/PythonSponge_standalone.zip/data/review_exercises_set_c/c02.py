a = 1
print(a)
b = 1
while b < 
    print(b)
    temp = a + b
    a = b
    b = temp