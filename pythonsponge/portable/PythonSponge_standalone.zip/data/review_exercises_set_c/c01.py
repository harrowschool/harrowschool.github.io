num = int(input("enter a whole number to start: "))
while num <= ________
    print(num)
    num = ___ ** 2