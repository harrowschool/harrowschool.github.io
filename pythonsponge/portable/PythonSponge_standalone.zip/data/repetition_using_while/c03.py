txt = "x"
while len(txt) <= 5:
    print(txt)
    txt = txt + "x"
print("done")