num = 1
while num <= 1000:
    print(num)
    num = num * 2
print("done")