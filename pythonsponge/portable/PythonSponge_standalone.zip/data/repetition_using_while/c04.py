txt = "{}"
while len(txt)
    print(txt)
    txt = txt +