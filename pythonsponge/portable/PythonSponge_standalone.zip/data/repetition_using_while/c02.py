num = 1
while num * num < 
print(num * num)
num = num + 1