from copy import d___c___

leg1 = [["Arsenal", "Liverpool"], ["Chelsea", "Southampton"], ["Manchester United", "Everton"]]

leg2 = d___c___(____)

for fixture in leg2:
    fixture.reverse()
	
print(leg1)
print(leg2)