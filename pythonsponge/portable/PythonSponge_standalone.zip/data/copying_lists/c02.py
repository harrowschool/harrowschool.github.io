my_name = input("enter my name: ")
your_name = input("enter your name: ")

friends = ['Jim', 'Amy', 'Tasha']

your_friends = list(______)
my_friends = list(______)

your_friends.append(my_name)
my_friends.append(_____)

print(f"my friends: {my_friends}")
print(f"your friends: {___________}")