# An example

Pages can be marked as *example* pages. These require no code change, and are marked as completed immediately when the student runs the code.  

*Note: the work is actually marked as completed once the program finishes execution. E.g. in this case after providing some input. This is to encourage engagement with the example program*
